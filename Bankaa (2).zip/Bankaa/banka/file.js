


const toggleBtn = document.querySelector(".side-bar-btn")
const sidebar = document.querySelector(".side-bar");
 
 toggleBtn.addEventListener('click', function(){
  sidebar.classList.toggle('show-sidebar') })



