const userDB = []


module.exports = {userDB}

