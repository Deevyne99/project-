

const navToggle = document.querySelector(".menu");
const links = document.querySelector(".nav-bar");

  navToggle.addEventListener("click", function () {
  
  links.classList.toggle("show-links");
})





