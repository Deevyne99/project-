const express = require('express')

const http = require('http')

const bcrypt = require('bcrypt')

const path = require('path')

const bodyParser = require('body-parser')

const users = require('./banka/data').userDB

const app = express()

app.use(bodyParser.urlencoded({extended:false}))
app.use(express.static(path.join(__dirname,'/banka')))

app.get('/',(req,res)=>{
    res.sendFile(path.join(__dirname,'./banka/index.html'))
})

app.post('/register/banka/v1',async (req,res) => {
    try{
        let foundUser = users.find((data) => req.body.email === data.email)
        if(!foundUser){
            let hashPassword = await bcrypt.hash(req.body.password,10);
            let newUser = {
                id:Date.now(),
                firstName: req.body.firstName,
                lastName: req.body.lastName,
                email: req.body.email,
                password: hashPassword,
                
            }
            users.push(newUser)
            console.log('User list',users);
            res.send(`Registration successful please click on the signin to login <a href="./banka/index.html">LogIn</a>`)
        }else{
            res.send("Email already used")
        }
    }catch{
        res.send("Internal server Error")
    }``
})
app.post('/login/banka/v1',async (req,res) => {
    try{
        let foundUser = users.find((data)=>req.body.email === data.email)
        if (req.body.email === "admin123@gmail.com"){
        if (foundUser){
            let submittedPass = req.body.password
            let storedPass = foundUser.password

            const passwordMatch = await bcrypt.compare(submittedPass, storedPass)
            if (passwordMatch){
                let usrname = foundUser.firstName
                res.send("admin login Successful")
            }
            else{
                res.send("Invalid email or password")
            }    
        }}
        else if (foundUser){
            let submittedPass = req.body.password
            let storedPass = foundUser.password

            const passwordMatch = await bcrypt.compare(submittedPass, storedPass)
            if (passwordMatch){
                let usrname = foundUser.firstName
                res.send("login Successful")
            }
            else{
                res.send("Invalid email or password")
            }
        }
        else {
            let fakePass = '$2b$$10$ifgfgfgfggfgfggggfgfga'
            await bcrypt.compare(req.body.password, fakePass)
            res.send('Invalid email or password')
        }
    } catch{
        res.send("Internal Server Error")
    }
})


app.listen(5000,(req,res)=>console.log('server listening on PORT 5000'))